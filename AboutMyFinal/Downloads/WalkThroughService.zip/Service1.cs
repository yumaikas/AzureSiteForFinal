﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace WalkThroughService
{
    //Deriving from ServiceBase allows us to write services. 
    public partial class MyNewService : ServiceBase
    {
        public MyNewService()
        {
            InitializeComponent();
            //Make sure that the event log exits, but don't try to recreate it
            //if it does.
            if (!EventLog.SourceExists("MySource")){
                EventLog.CreateEventSource("MySource", 
                    "MyNewLog");
            }
            //Attach the event log that we have to the one that was created 
            //above
            eventLog1.Source = "MySource";
            eventLog1.Log = "MyNewLog";
        }

        //This method runs when your service starts, and accepts command line
        //parameters.
        protected override void OnStart(string[] args)
        {
            //Write an entry to the event log.
            eventLog1.WriteEntry("In OnStart!");
        }

        //This method runs when the service is stopped for any reason.
        protected override void OnStop()
        {
            eventLog1.WriteEntry("In OnStop!");
        }
    }
}
