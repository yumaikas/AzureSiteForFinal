﻿//Created by Andrew Owen for Professor Vanselow
//This code is based on a LINQ walk-through


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqToNorthwindCmd
{
    class Customer
    {
        public string CustomerID { get; set; }
        public string City { get; set; }

        public override string ToString()
        {
            return CustomerID + "\t" + City;
        }
    }
}
